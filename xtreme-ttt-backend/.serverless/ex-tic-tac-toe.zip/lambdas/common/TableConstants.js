const Responses = {
  USERS: "exttt-users",
  CONNECTIONS: "exttt-connections",
  GAMES: "exttt-games",
};

module.exports = Responses;
