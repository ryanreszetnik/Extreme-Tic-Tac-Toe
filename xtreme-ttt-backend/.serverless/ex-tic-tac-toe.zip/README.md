https://www.freecodecamp.org/news/complete-back-end-system-with-serverless/#setup
